import { Component } from '@angular/core';

@Component({
  template: `
    <h1>Advanced Concepts</h1>
        <div class="container-fluid">
            <div class="row align-items-center">
                <div class="col-12">
                    <div></div>
                </div>
            </div>
        </div>
  `,
  styles: [``]
})
export class AdvancedComponent {}