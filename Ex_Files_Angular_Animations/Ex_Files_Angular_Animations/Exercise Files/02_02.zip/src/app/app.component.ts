import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
    <p>Angular Animations</p>
  `,
  styles: [``]
})
export class AppComponent {} 